#!/usr/bin/env python3
"""Local Signalforge web app and Yahoo Finance chart-data proxy.

Yahoo Finance's chart endpoint is undocumented and may change or throttle requests.
This prototype backend only reads market data; it never submits orders.
"""
from __future__ import annotations

import json
import re
import time
import os
import hashlib
import hmac
import secrets
import sqlite3
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, quote, urlparse
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
HOST, PORT = "127.0.0.1", 8765
DB_PATH = ROOT / "signalforge.sqlite3"
SESSION_SECONDS = 7 * 24 * 60 * 60
CACHE_SECONDS = 15
NEWS_CACHE_SECONDS = 90
NEWS_CACHE: dict[str, tuple[float, dict]] = {}
NEWS_FEEDS = [("CNBC Markets", "https://www.cnbc.com/id/10000664/device/rss/rss.html")]
_custom_feeds = os.environ.get("NEWS_FEEDS", "")
if _custom_feeds:
    NEWS_FEEDS = []
    for _item in _custom_feeds.split(";"):
        _name, _sep, _url = _item.partition("|")
        if _sep and _url.startswith("https://"):
            NEWS_FEEDS.append((_name.strip() or "RSS", _url.strip()))
CACHE: dict[tuple[str, str, str], tuple[float, dict]] = {}
RANGES = {
    ("1d", "1m"), ("1d", "5m"), ("5d", "5m"),
    ("1mo", "30m"), ("3mo", "1d"), ("1y", "1d"),
}


def db_connect() -> sqlite3.Connection:
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    return db


def init_db() -> None:
    with db_connect() as db:
        db.execute("PRAGMA journal_mode=WAL")
        db.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL UNIQUE,
                display_name TEXT NOT NULL,
                password_salt BLOB NOT NULL,
                password_hash BLOB NOT NULL,
                created_at INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS sessions (
                token_hash TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                expires_at INTEGER NOT NULL,
                created_at INTEGER,
                revoked_at INTEGER
            );
            CREATE INDEX IF NOT EXISTS sessions_expiry ON sessions(expires_at);
        """)
        # Upgrade an existing database created before session history was added.
        columns = {row[1] for row in db.execute("PRAGMA table_info(sessions)")}
        if "created_at" not in columns:
            db.execute("ALTER TABLE sessions ADD COLUMN created_at INTEGER")
        if "revoked_at" not in columns:
            db.execute("ALTER TABLE sessions ADD COLUMN revoked_at INTEGER")
        db.execute("UPDATE sessions SET created_at = expires_at - ? WHERE created_at IS NULL",
                   (SESSION_SECONDS,))


def password_hash(password: str, salt: bytes) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 310_000)


init_db()


class Handler(BaseHTTPRequestHandler):
    server_version = "SignalforgePrototype/1.0"

    def log_message(self, fmt: str, *args: object) -> None:
        print("[%s] %s" % (self.log_date_time_string(), fmt % args))

    def send_json(self, status: int, payload: dict, headers: dict[str, str] | None = None) -> None:
        body = json.dumps(payload, separators=(",", ":")).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for name, value in (headers or {}).items():
            self.send_header(name, value)
        self.end_headers()
        self.wfile.write(body)

    def read_json(self) -> dict:
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 1 or length > 16_384:
                raise ValueError("Invalid request size.")
            value = json.loads(self.rfile.read(length))
            if not isinstance(value, dict):
                raise ValueError("Expected a JSON object.")
            return value
        except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
            raise ValueError("Request must contain a valid JSON object.")

    def cookie_token(self) -> str | None:
        for item in self.headers.get("Cookie", "").split(";"):
            name, sep, value = item.strip().partition("=")
            if sep and name == "sf_session":
                return value
        return None

    def current_user(self) -> sqlite3.Row | None:
        token = self.cookie_token()
        if not token:
            return None
        digest = hashlib.sha256(token.encode()).hexdigest()
        with db_connect() as db:
            return db.execute(
                "SELECT users.id, users.email, users.display_name FROM sessions "
                "JOIN users ON users.id = sessions.user_id "
                "WHERE sessions.token_hash = ? AND sessions.expires_at >= ? AND sessions.revoked_at IS NULL",
                (digest, int(time.time())),
            ).fetchone()

    def require_user(self) -> sqlite3.Row | None:
        user = self.current_user()
        if not user:
            self.send_json(401, {"error": "Sign in to continue."})
        return user

    def auth(self, path: str) -> None:
        if path == "/api/auth/me" and self.command == "GET":
            user = self.current_user()
            with db_connect() as db:
                has_users = db.execute("SELECT 1 FROM users LIMIT 1").fetchone() is not None
            self.send_json(200, {"user": dict(user) if user else None, "needsSetup": not has_users})
            return
        if path == "/api/auth/logout" and self.command == "POST":
            token = self.cookie_token()
            if token:
                with db_connect() as db:
                    db.execute("UPDATE sessions SET revoked_at = ? WHERE token_hash = ? AND revoked_at IS NULL",
                               (int(time.time()), hashlib.sha256(token.encode()).hexdigest()))
            self.send_json(200, {"ok": True}, {"Set-Cookie": "sf_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0"})
            return
        if path not in ("/api/auth/register", "/api/auth/login") or self.command != "POST":
            self.send_json(404, {"error": "Unknown authentication route."})
            return
        try:
            data = self.read_json()
        except ValueError as exc:
            self.send_json(400, {"error": str(exc)})
            return
        email = str(data.get("email", "")).strip().casefold()
        password = str(data.get("password", ""))
        name = str(data.get("name", "")).strip()[:80]
        if len(email) > 254 or not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", email):
            self.send_json(400, {"error": "Enter a valid email address."})
            return
        if len(password) < 10 or len(password) > 256:
            self.send_json(400, {"error": "Use a password with 10–256 characters."})
            return
        now = int(time.time())
        with db_connect() as db:
            row = db.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
            if path.endswith("register"):
                if not name:
                    self.send_json(400, {"error": "Enter your name."})
                    return
                if row:
                    self.send_json(409, {"error": "An account with this email already exists."})
                    return
                salt = secrets.token_bytes(16)
                cursor = db.execute(
                    "INSERT INTO users(email, display_name, password_salt, password_hash, created_at) VALUES(?,?,?,?,?)",
                    (email, name, salt, password_hash(password, salt), now),
                )
                user_id = cursor.lastrowid
            else:
                if not row or not hmac.compare_digest(password_hash(password, row["password_salt"]), row["password_hash"]):
                    self.send_json(401, {"error": "Email or password is incorrect."})
                    return
                user_id = row["id"]
                name = row["display_name"]
            token = secrets.token_urlsafe(32)
            db.execute("INSERT INTO sessions(token_hash,user_id,expires_at,created_at) VALUES(?,?,?,?)",
                       (hashlib.sha256(token.encode()).hexdigest(), user_id, now + SESSION_SECONDS, now))
        self.send_json(200, {"user": {"id": user_id, "email": email, "display_name": name}},
                       {"Set-Cookie": f"sf_session={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={SESSION_SECONDS}"})

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path.startswith("/api/auth/"):
            self.auth(parsed.path)
            return
        if parsed.path == "/api/health":
            self.send_json(200, {"ok": True, "provider": "Yahoo Finance chart endpoint", "cacheSeconds": CACHE_SECONDS})
            return
        if parsed.path == "/api/market":
            if not self.require_user():
                return
            self.market(parse_qs(parsed.query))
            return
        if parsed.path == "/api/news":
            if not self.require_user():
                return
            self.news(parse_qs(parsed.query))
            return
        self.static_file(parsed.path)

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path.startswith("/api/auth/"):
            self.auth(parsed.path)
            return
        self.send_json(404, {"error": "Unknown API route."})

    def market(self, query: dict[str, list[str]]) -> None:
        symbol = query.get("symbol", ["SPY"])[0].upper().strip()
        period = query.get("range", ["1d"])[0]
        interval = query.get("interval", ["1m"])[0]
        if not re.fullmatch(r"[A-Z0-9.^=_-]{1,20}", symbol):
            self.send_json(400, {"error": "Invalid symbol."})
            return
        if (period, interval) not in RANGES:
            self.send_json(400, {"error": "Unsupported chart range or interval."})
            return
        key = (symbol, period, interval)
        cached = CACHE.get(key)
        if cached and time.time() - cached[0] < CACHE_SECONDS:
            self.send_json(200, cached[1])
            return
        url = (f"https://query1.finance.yahoo.com/v8/finance/chart/{quote(symbol, safe='')}"
               f"?range={period}&interval={interval}&includePrePost=false&events=div%2Csplits")
        request = Request(url, headers={"User-Agent": "Mozilla/5.0 SignalforgePrototype/1.0", "Accept": "application/json"})
        try:
            with urlopen(request, timeout=12) as response:
                raw = json.loads(response.read())
        except (HTTPError, URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
            message = getattr(exc, "reason", None) or str(exc)
            self.send_json(502, {"error": f"Market data provider unavailable: {message}"})
            return
        chart = raw.get("chart", {})
        if chart.get("error"):
            self.send_json(502, {"error": chart["error"].get("description", "Market data provider returned an error.")})
            return
        results = chart.get("result") or []
        if not results:
            self.send_json(404, {"error": "No market data returned for this symbol."})
            return
        result = results[0]
        timestamps = result.get("timestamp") or []
        quote_data = ((result.get("indicators", {}).get("quote") or [{}])[0])
        opens = quote_data.get("open") or []
        highs = quote_data.get("high") or []
        lows = quote_data.get("low") or []
        closes = quote_data.get("close") or []
        volumes = quote_data.get("volume") or []
        candles = []
        for i, timestamp in enumerate(timestamps):
            values = [opens[i] if i < len(opens) else None,
                      highs[i] if i < len(highs) else None,
                      lows[i] if i < len(lows) else None,
                      closes[i] if i < len(closes) else None]
            if any(v is None for v in values):
                continue
            candles.append({"time": timestamp, "open": values[0], "high": values[1],
                            "low": values[2], "close": values[3],
                            "volume": volumes[i] if i < len(volumes) and volumes[i] is not None else 0})
        meta = result.get("meta", {})
        payload = {
            "symbol": symbol,
            "currency": meta.get("currency", "USD"),
            "exchange": meta.get("fullExchangeName") or meta.get("exchangeName") or "Market",
            "timezone": meta.get("exchangeTimezoneName", "UTC"),
            "range": period,
            "interval": interval,
            "fetchedAt": int(time.time()),
            "regularMarketPrice": meta.get("regularMarketPrice"),
            "previousClose": meta.get("chartPreviousClose") or meta.get("previousClose"),
            "candles": candles,
        }
        if not candles:
            self.send_json(502, {"error": "Provider returned no complete OHLC candles."})
            return
        CACHE[key] = (time.time(), payload)
        self.send_json(200, payload)

    def news(self, query: dict[str, list[str]]) -> None:
        symbol = query.get("symbol", ["MARKET"])[0].upper().strip()
        if not re.fullmatch(r"[A-Z0-9.^=_-]{1,20}", symbol):
            self.send_json(400, {"error": "Invalid symbol."})
            return
        cached = NEWS_CACHE.get(symbol)
        if cached and time.time() - cached[0] < NEWS_CACHE_SECONDS:
            self.send_json(200, cached[1])
            return
        aliases = {"NVDA": ["NVIDIA"], "AAPL": ["APPLE"], "MSFT": ["MICROSOFT"],
                   "SPY": ["S&P 500", "SPDR"], "QQQ": ["NASDAQ", "NASDAQ 100"],
                   "BTC-USD": ["BITCOIN", "BTC"], "TSLA": ["TESLA"]}
        terms = [symbol.replace("-USD", "")] + aliases.get(symbol, []) if symbol != "MARKET" else []
        rows = []
        try:
            for source, feed_url in NEWS_FEEDS:
                req = Request(feed_url, headers={"User-Agent": "SignalforgePrototype/1.0 (RSS headline reader)", "Accept": "application/rss+xml, application/atom+xml, application/xml, text/xml"})
                with urlopen(req, timeout=10) as response:
                    root = ET.fromstring(response.read())
                for item in root.findall(".//item"):
                    title = (item.findtext("title") or "").strip()
                    link = (item.findtext("link") or "").strip()
                    published = (item.findtext("pubDate") or "").strip()
                    if not title or not link or not link.startswith("https://"):
                        continue
                    try:
                        stamp = parsedate_to_datetime(published).timestamp() if published else 0
                    except (TypeError, ValueError, OverflowError):
                        stamp = 0
                    rows.append({"title": title, "url": link, "source": source,
                                 "published": published, "timestamp": stamp})
        except Exception as exc:
            if not rows:
                self.send_json(502, {"error": f"News feed unavailable: {exc}"})
                return
        # Deduplicate feeds and calculate a deliberately simple descriptive keyword score.
        unique = {row["url"]: row for row in rows}
        articles = list(unique.values())
        if terms:
            matched = [row for row in articles if any(term.casefold() in row["title"].casefold() for term in terms)]
            if matched:
                articles = matched
        positive = ("beat", "beats", "growth", "surge", "gain", "gains", "upgrade", "record", "profit", "strong", "rally", "bullish", "approval", "deal", "rises", "higher")
        negative = ("miss", "misses", "fall", "falls", "drop", "drops", "cuts", "downgrade", "loss", "weak", "lawsuit", "probe", "selloff", "bearish", "warning", "lower", "decline")
        scored = []
        for row in articles:
            text = row["title"].casefold()
            pos = sum(text.count(word) for word in positive)
            neg = sum(text.count(word) for word in negative)
            score = (pos - neg) / max(pos + neg, 1)
            scored.append((row, score))
        scored.sort(key=lambda item: item[0]["timestamp"], reverse=True)
        average = sum(score for _, score in scored) / len(scored) if scored else 0.0
        score = int(round(average * 100))
        label = "Positive bias" if score >= 20 else "Negative bias" if score <= -20 else "Mixed / neutral"
        result_articles = [{"title": row["title"], "url": row["url"], "source": row["source"],
                            "published": row["published"], "sentiment": int(round(item_score * 100))}
                           for row, item_score in scored[:20]]
        result = {"symbol": symbol, "scope": "symbol" if terms and any(
                      any(term.casefold() in row["title"].casefold() for term in terms) for row, _ in scored) else "market",
                  "fetchedAt": int(time.time()),
                  "sentiment": {"score": score, "label": label, "count": len(result_articles)},
                  "method": "headline keyword counts; descriptive only", "articles": result_articles}
        NEWS_CACHE[symbol] = (time.time(), result)
        self.send_json(200, result)

    def static_file(self, path: str) -> None:
        relative = "index.html" if path in ("", "/") else path.lstrip("/")
        target = (ROOT / relative).resolve()
        if ROOT not in target.parents and target != ROOT:
            self.send_error(403)
            return
        if not target.is_file():
            self.send_error(404)
            return
        content_type = "text/html; charset=utf-8" if target.suffix == ".html" else "text/plain; charset=utf-8"
        body = target.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    print(f"Signalforge running at http://{HOST}:{PORT}")
    print("Market data: Yahoo Finance chart endpoint; refreshes are cached for 15 seconds.")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
