SIGNALFORGE — AI TRADING LAB PROTOTYPE

Run the local backend from this folder:
  python3 server.py

Then open http://127.0.0.1:8765 in your browser. The backend serves the app and provides /api/market OHLCV data to the Overview candlestick chart.

Account login and local database
- The first visit shows a sign-in screen. Choose “Create an account” to register the first local user; passwords must be at least 10 characters.
- Accounts and login-session history are stored in signalforge.sqlite3, created automatically next to server.py on first startup. Sign-ins add rows to `sessions`; sign-out revokes the row so it remains visible as history.
- Passwords are stored as salted PBKDF2-HMAC-SHA256 hashes. The browser receives only a random HttpOnly, SameSite session cookie.
- This is a single-machine prototype. Keep the database file private and back it up if needed. Deleting signalforge.sqlite3 removes all local accounts and sessions.
- The app should be opened through the local server URL above. Directly opening index.html will not enable login or database access.

Screens
- Overview: real OHLC candlestick and volume chart, refreshes every 15 seconds; symbol and timeframe selectors; portfolio, positions, strategy status, activity, and demo agent chat monitor
- Strategies: view, pause/resume, add a draft, and rename strategies
- AI agent: describe a strategy idea, generate a rule-template draft, and run a guarded paper-simulation cycle
- Backtesting: configure and run a sample historical simulation
- Portfolio: inspect simulated positions and export CSV
- Orders: filter, cancel, or create and confirm simulated paper orders
- Activity: review example signals, orders, and risk events
- Setup & risk: edit example account and risk settings

Market data notes
The backend retrieves OHLCV candles from Yahoo Finance's chart endpoint and caches requests for 15 seconds. The endpoint is undocumented, may be throttled or changed, and does not guarantee real-time data. If live-feed SLAs are required, configure a supported licensed provider such as Alpaca and its market-data credentials rather than relying on this prototype source. If the provider is unavailable, the chart displays an error state.

Prototype boundaries
The strategy copilot uses local keyword-based templates; it is not connected to an AI model. The agent runner uses a fixed sample signal snapshot and creates local paper-order records. There is no broker or exchange connection and no live order execution. Settings are not persisted after the page is closed. Do not enter credentials or API keys into this prototype.
